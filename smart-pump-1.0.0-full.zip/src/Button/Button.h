/*
 * Push button control
 *
 * This source file can be found under:
 * http://www.github.com/arduino-library/Button
 *
 * Please visit:
 *   http://www.microfarad.de
 *   http://www.github.com/microfarad-de
 *   http://www.github.com/arduino-library
 *
 * Copyright (C) 2019 Karim Hraibi (khraibi at gmail.com)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef __BUTTON_H
#define __BUTTON_H

#include <Arduino.h>


/*
 * Push button implementation class
 */
class ButtonClass {
  public:
    void initialize (uint8_t digitalPin, uint8_t activeLevel=LOW, uint8_t debounceSamples=10);
    void read (void);
    void press (void);
    void release (void);
    bool rising (void);
    bool falling (void);
    bool fallingLongPress (void);
    bool fallingContinuous (void);
    bool longPress (uint32_t longPressDuration=500);
    bool longPressContinuous (uint32_t longPressDuration=500);

    bool pressed    = false;
    bool wasPressed = false;

  private:
    uint32_t longPressTs       = 0;
    uint32_t debounceTs        = 0;
    uint32_t longPressDuration = 500;
    uint8_t  debounceSamples   = 10;
    uint8_t  debounceCounter   = 0;
    uint8_t  digitalPin;
    uint8_t  activeLevel       = LOW;
    bool     longPressed       = false;
    bool     wasLongPressed    = false;
    bool     initialized       = false;
};



#endif // __BUTTON_H
